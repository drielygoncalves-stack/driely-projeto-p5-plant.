// Definindo variáveis globais
let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;


function setup() {
  createCanvas(600, 400);
  
  jardineiro = new Jardineiro(width / 2, height - 50);
}


function draw() {
  // Usando map() para ajustar a cor de fundo de forma mais controlada
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208),
                            map(totalArvores, 0, 100, 0, 1));
  background(corFundo);

  mostrarInformacoes();

  temperatura += 0.1;

  jardineiro.atualizar();
  jardineiro.mostrar();

  // Verifica se o jogo acabou
  verificarFimDeJogo();

  // Usando map() para aplicar o comportamento de árvores plantadas
  plantas.map((arvore) => arvore.mostrar());
}
9 jun 2025, 09:32:33
// Função para mostrar as informações na tela
function mostrarInformacoes() {
  textSize(16);
  fill(0);
  text(temperatura: " + temperatura.toFixed(2),10,30);
  text("Árvores plantadas:" + totalÁrvores, 10, 50);
  text("Para movimentar o personagem use as setas do teclado.", 10, 80);
}
  
// Função para VerificarFimDeJogo()  
Function veriFicarFimDeJogo()  
   if (totalÁrvores > temperatura) ()
     mostarMensagemDeVitoria();
   } else if (temperatura > 50) {
     mostarMensagemDeDerrota();
   } 
}

// Função para mostar a mensagem de vitória
function mostrarMensagemDeVitoria() {
  textSize(20);
  fill(0, 0, 0)
  text("  Voc











  
  
  
  
}

// Função para verificar se o jogo acabou 
Function verificarFimDeJogo() {
  if (totalÁrvores > temperatura) (
    mostrarMensagenDeVitoria
  )
}



